# 0.8.1 会话识别修复版

用户诊断显示 Shizuku 已连接，但完整通道因找不到可静音会话而退出。

修正：AudioPlaybackConfiguration 的会话读取方法为 getSessionId；旧实现错误调用了 getAudioSessionId。抽出 PlaybackSessions，回归测试使用只提供平台实际方法名的配置对象，检查目标 UID、活跃状态、正数会话、去重，以及反射错误不会被吞掉。Shizuku 服务版本由 5 升为 6，使后续安装构建更新用户服务。

保留最近会话查询错误，避免被通用 30 秒超时报错覆盖。完整模式增加累计输入帧数、历史峰值和曾检测非零输入的标记，区分当前静默与从未捕获。没有更改权限或原声衰减策略；不代表 HyperOS 反射访问、原声衰减和完整接管已在手机验证。

已重建并签名为 Sonic-0.8.1-repair.apk。旧私钥不可恢复，因此新应用 ID 为 cn.xiaohei.sonic.repair，名称为“黑音 · 修复版”；可和 cn.xiaohei.sonic 旧版并存，不能直接覆盖旧版，设置和权限不自动迁移。使用前请关闭旧版引擎，避免两路音频处理相互影响。Shizuku 用户服务 tag、Binder token 和 provider authority 已隔离。原有 JNI 包名保留以匹配原生库导出符号。

新签名为独立 PKCS12 私钥，密码使用随机值。签名材料独立备份在 Sonic-signing-backup.zip 中，不包含在公开源码包和 APK 里。后续 cn.xiaohei.sonic.repair 更新应恢复同一签名材料；build.sh 缺少签名路径或密码文件时失败，避免自动生成新密钥导致再次无法覆盖。

构建使用 Android platform 35、build-tools 35.0.0、JRE 17 与 ECJ 3.38。SIGNING_KEYSTORE 指向私钥，SIGNING_STORE_PASS_FILE 指向密码文件，别名默认 sonic-repair。Java 编译、签名、安装包结构和回归测试通过；没有连接用户手机，尚未验证实际安装、HyperOS 会话访问和原声衰减效果。
