#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT to an SDK with platform 35 and build-tools 35.0.0}"
BT="$ANDROID_SDK_ROOT/build-tools/35.0.0"
PLATFORM="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
python3 - <<'PY'
from pathlib import Path
import shutil
for name in ('gen', 'classes', 'dex'):
    path = Path('build') / name
    if path.exists():
        shutil.rmtree(path)
PY
mkdir -p build/gen build/classes build/dex
"$BT/aapt2" compile --dir res -o build/resources.zip
"$BT/aapt2" link -o build/base.apk -I "$PLATFORM" --manifest AndroidManifest.xml --java build/gen -A assets build/resources.zip
mapfile -t libraries < <(find libs -name '*.jar' | sort)
CP="$PLATFORM"
for lib in "${libraries[@]}"; do CP="$CP:$lib"; done
mapfile -t sources < <(find src build/gen -name '*.java' | sort)
if command -v javac >/dev/null; then
  javac -source 8 -target 8 -encoding UTF-8 -classpath "$CP" -d build/classes "${sources[@]}"
else
  : "${ECJ_JAR:?Set ECJ_JAR when javac is unavailable}"
  java -jar "$ECJ_JAR" -8 -encoding UTF-8 -classpath "$CP" -d build/classes "${sources[@]}"
fi
mapfile -t classes < <(find build/classes -name '*.class' | sort)
"$BT/d8" --lib "$PLATFORM" --min-api 26 --output build/dex "${classes[@]}" "${libraries[@]}"
cp build/base.apk build/unsigned.apk
(cd native && zip -qr ../build/unsigned.apk lib)
(cd build/dex && zip -q ../unsigned.apk classes*.dex)
"$BT/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
: "${SIGNING_KEYSTORE:?Set SIGNING_KEYSTORE; a new key must never be generated silently}"
: "${SIGNING_STORE_PASS_FILE:?Set SIGNING_STORE_PASS_FILE to the private password file}"
"$BT/apksigner" sign --ks "$SIGNING_KEYSTORE" --ks-pass "file:$SIGNING_STORE_PASS_FILE" --ks-key-alias "${SIGNING_KEY_ALIAS:-sonic-repair}" --out build/Sonic-1.0.apk build/aligned.apk
"$BT/apksigner" verify --verbose build/Sonic-1.0.apk
