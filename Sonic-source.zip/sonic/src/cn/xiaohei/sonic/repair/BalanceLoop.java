package cn.xiaohei.sonic.repair;
/** Platform-independent controller; native system balance writes are supplied by the shell service. */
final class BalanceLoop {
 interface Backend {float read() throws Exception;int write(float balance) throws Exception;}
 final Backend backend;boolean active,restorePending;float original,current;String status="尚未开启";
 double phase;long previous,heartbeat;int period=8,depth=100;
 BalanceLoop(Backend b){backend=b;}
 void start(long now,int seconds,int amount){
  period=Math.max(2,Math.min(20,seconds));depth=Math.max(0,Math.min(100,amount));heartbeat=now;
  if(active)return;
  if(restorePending){status="上次恢复未成功，请先点停止并恢复";return;}
  try{original=backend.read();if(!Float.isFinite(original)||Math.abs(original)>1)throw new IllegalStateException("系统平衡读数异常");current=original;
   int code=backend.write(original);if(code!=0){status="系统拒绝平衡写入，返回码 "+code;return;}
   restorePending=true;active=true;phase=0;previous=now;status="系统平衡接口已启用；请用耳机确认听感";
  }catch(Exception e){status="接口不可用："+message(e);}
 }
 void beat(long now){heartbeat=now;}
 void tick(long now){if(!active)return;if(now-heartbeat>5000){stop("与主程序失联，已停止");return;}
  double dt=Math.max(0,(now-previous)/1000.0);previous=now;phase=(phase+dt*2*Math.PI/period)%(2*Math.PI);
  float target=(float)Math.sin(phase)*depth/100f;
  current+=(float)(1-Math.exp(-dt/.045))*(target-current);
  try{int result=backend.write(current);if(result!=0){stop("系统写入失败："+result);}}
  catch(Exception e){stop("接口异常："+message(e));}
 }
 void stop(String reason){active=false;
  if(restorePending)try{int code=backend.write(original);if(code!=0){status=reason+"；恢复失败："+code;return;}current=original;restorePending=false;}catch(Exception e){status=reason+"；恢复失败："+message(e);return;}
  status=reason+"；原始声道平衡已恢复";
 }
 static String message(Throwable t){while(t.getCause()!=null)t=t.getCause();String s=t.getMessage();return t.getClass().getSimpleName()+(s==null?"":": "+s);}
}
