package cn.xiaohei.sonic.repair;
/** No-root capture test state. Playback is opt-in and expires after five seconds. */
final class CaptureProbe {
 volatile long capturedFrames,previewUntil;volatile float peak;volatile boolean signalSeen;
 void record(float[] input,int count){float p=0;for(int i=0;i<count;i++){if(!Float.isFinite(input[i]))throw new IllegalStateException("内部音频包含异常样本");p=Math.max(p,Math.abs(input[i]));}peak=p;signalSeen|=p>.0001f;capturedFrames+=count/2;}
 void requestPreview(long now){previewUntil=now+5000;}
 void stopPreview(){previewUntil=0;}
 boolean previewing(long now){return signalSeen&&previewUntil>0&&now<previewUntil;}
}
