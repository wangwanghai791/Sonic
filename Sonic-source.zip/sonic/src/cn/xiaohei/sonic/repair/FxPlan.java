package cn.xiaohei.sonic.repair;
/** Card definitions and native engine parameters. Presets are original combinations. */
final class FxPlan {
 static final String[] NAMES={"原声对比","8D 环绕","360 环绕","超重低音","清澈人声","3D 空间","现场氛围","动感电音","摇滚音效","复古唱片","自然听感","温暖耐听","人声靠前","柔化齿音"};
 static final String[] DESC={"旁路音色处理","声音在左右耳流动","声场展开 · 短混响","动态低频 · 厚实鼓点","人声中频 · 耳机交叉馈送","HRTF 耳机空间模拟","音乐厅混响 · 宽阔声场","动态低音 · 明亮节奏","温暖饱和 · 低频张力","柔和高频 · 管式饱和","无混响 · 不扩展声场","适度厚度 · 柔和高频","突出人声存在感","适度衰减刺耳高频"};
 final boolean bass,reverb,wide,cross,tube;final int room,crossMode;final float bassGain,width,drive;final String eq;
 FxPlan(int mode){
  bass=mode==3||mode==7||mode==8;reverb=mode==2||mode==6;wide=mode==2||mode==6||mode==7;
  cross=mode==4||mode==5;tube=mode==8||mode==9;room=mode==6?5:7;crossMode=mode==5?2:0;
  bassGain=mode==3?9:5;width=mode==2?65:mode==6?40:25;drive=mode==9?300:160;
  eq=mode==4?"60 -3;230 -1;1000 2;2500 3;7000 0;14000 -1":mode==7?"60 2;230 0;1000 -1;4000 2;14000 3":mode==8?"60 2;230 1;1000 0;4000 2;14000 0":mode==9?"60 1;230 2;1000 0;4000 -2;14000 -5":"";
 }
 static int valid(int n){return Math.max(0,Math.min(NAMES.length-1,n));}
}
