package cn.xiaohei.sonic.repair;
/** Upstream alloc returns sentinels 0, 1 or 2, otherwise an opaque 64-bit pointer.
 * Android tagged heap pointers can be negative when represented by Java long. */
final class NativeHandle {
 static boolean allocated(long value){return value!=0L&&value!=1L&&value!=2L;}
 static long require(long value){if(!allocated(value))throw new IllegalStateException("JamesDSP 分配失败，原生错误码："+value);return value;}
}
