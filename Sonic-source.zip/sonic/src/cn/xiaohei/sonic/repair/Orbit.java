package cn.xiaohei.sonic.repair;
/** Continuous left/right auto-pan. No channel boost, and no HRTF/height claims. */
final class Orbit {
 private double phase;
 private float left=1,right=1;
 private final float[] output=new float[2];
 float position;
 float[] step(double seconds,double period,double depth,boolean enabled){
  double dt=Math.max(0,seconds);
  if(enabled)phase=(phase+dt*2*Math.PI/Math.max(2,period))%(2*Math.PI);
  position=enabled?(float)(Math.sin(phase)*Math.max(0,Math.min(1,depth))):0;
  // Keep the stronger channel at unity. Only attenuate the opposite channel.
  float targetL=position>0?1-position:1;
  float targetR=position<0?1+position:1;
  // Smooth parameter, bypass, and depth changes to avoid volume discontinuities.
  float a=(float)(1-Math.exp(-dt/.045));
  left+=a*(targetL-left);right+=a*(targetR-right);
  output[0]=left;output[1]=right;return output;
 }
 static float decibels(float gain){return (float)Math.max(-60,20*Math.log10(Math.max(.001,gain)));}
}
