package cn.xiaohei.sonic.repair;
import java.util.LinkedHashSet;
import java.util.List;
/** AudioPlaybackConfiguration uses getSessionId, not AudioTrack.getAudioSessionId. */
final class PlaybackSessions {
 static int[] matching(List<?> configs,int uid)throws Exception {
  if(configs==null)throw new IllegalStateException("系统未返回播放配置列表");
  LinkedHashSet<Integer> ids=new LinkedHashSet<>();
  for(Object config:configs){
   Class<?> type=config.getClass();
   int owner=((Number)type.getMethod("getClientUid").invoke(config)).intValue();
   boolean active=(Boolean)type.getMethod("isActive").invoke(config);
   if(owner==uid&&active){
    int session=((Number)type.getMethod("getSessionId").invoke(config)).intValue();
    if(session>0)ids.add(session);
   }
  }
  int[] result=new int[ids.size()];int index=0;for(int id:ids)result[index++]=id;return result;
 }
}
