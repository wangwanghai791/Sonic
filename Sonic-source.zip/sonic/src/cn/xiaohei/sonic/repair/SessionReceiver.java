package cn.xiaohei.sonic.repair;
import android.content.*;
import android.media.audiofx.AudioEffect;
public class SessionReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){SoundService s=SoundService.live;if(s==null)return;int id=i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION,-1);if(id<=0)return;if(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION.equals(i.getAction()))s.attach(id,i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME));else if(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION.equals(i.getAction()))s.detach(id);}
}
