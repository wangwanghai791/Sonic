package cn.xiaohei.sonic.repair;
import android.content.*;import android.content.pm.PackageManager;import android.os.*;import rikka.shizuku.Shizuku;
final class ShizukuBridge {
 final SoundService service;final Binder owner=new Binder();final Handler handler=new Handler(Looper.getMainLooper());
 IBinder remote;boolean binding,active,restoring,closed,requestFailed;int uid=-1;float position;String status="尚未连接 Shizuku";
 final Shizuku.UserServiceArgs args;
 ShizukuBridge(SoundService s){service=s;args=new Shizuku.UserServiceArgs(new ComponentName(s,ShizukuPanService.class)).daemon(true).processNameSuffix("system_balance").tag("sonic-repair-system-balance-v1").version(6);handler.postDelayed(heartbeat,1000);}
 final ServiceConnection connection=new ServiceConnection(){public void onServiceConnected(ComponentName n,IBinder binder){if(closed)return;binding=false;remote=binder;requestFailed=false;try{call(ShizukuPanService.STATUS);sync();}catch(Exception e){fail(e);}}
  public void onServiceDisconnected(ComponentName n){remote=null;binding=false;active=false;status="Shizuku 通道已断开；请检查服务并重新连接";}};
 final Runnable heartbeat=new Runnable(){public void run(){if(closed)return;if(remote!=null)try{call(ShizukuPanService.HEARTBEAT);}catch(Exception e){fail(e);}handler.postDelayed(this,1000);}};
 void connect(){if(closed)return;if(remote!=null){requestFailed=false;sync();return;}if(binding)return;try{
  if(!Shizuku.pingBinder()){status="Shizuku 未运行，请先在 Shizuku 中启动无线调试服务";return;}
  if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED){status="尚未授权，请点「授权并连接 Shizuku」";return;}
  binding=true;status="正在启动 Shizuku 声道服务…";Shizuku.bindUserService(args,connection);
  handler.postDelayed(()->{if(binding&&remote==null){binding=false;status="连接超时，请确认 Shizuku 已运行并重新连接";}},10000);
 }catch(Exception e){binding=false;fail(e);}}
 void sync(){if(closed)return;if(!service.cfg.shell){stop();return;}if(remote==null){connect();return;}try{
  if(service.capture==null&&service.cfg.enabled&&service.cfg.orbit){if(!requestFailed)call(ShizukuPanService.START);}
  else call(ShizukuPanService.STOP);
 }catch(Exception e){fail(e);}}
 void call(int code)throws Exception{if(remote==null)throw new IllegalStateException("Not connected");Parcel data=Parcel.obtain(),reply=Parcel.obtain();try{
  data.writeInterfaceToken(ShizukuPanService.TOKEN);if(code==ShizukuPanService.START){data.writeStrongBinder(owner);data.writeInt(service.cfg.period);data.writeInt(service.cfg.depth);}
  if(!remote.transact(code,data,reply,0))throw new IllegalStateException("Unsupported balance protocol");reply.readException();uid=reply.readInt();active=reply.readInt()!=0;restoring=reply.readInt()!=0;position=reply.readFloat();status=reply.readString();if(code==ShizukuPanService.START&&!active)requestFailed=true;
 }finally{data.recycle();reply.recycle();}}
 int[] sessions(int target)throws Exception{if(remote==null)throw new IllegalStateException("请先连接 Shizuku");Parcel data=Parcel.obtain(),reply=Parcel.obtain();try{data.writeInterfaceToken(ShizukuPanService.TOKEN);data.writeInt(target);if(!remote.transact(ShizukuPanService.SESSIONS,data,reply,0))throw new IllegalStateException("请重新连接以更新 Shizuku 服务");reply.readException();int[] ids=reply.createIntArray();return ids==null?new int[0]:ids;}finally{data.recycle();reply.recycle();}}
 boolean connected(){return remote!=null&&remote.isBinderAlive();}
 void fail(Exception e){status="Shizuku 错误："+BalanceLoop.message(e);active=false;requestFailed=true;if(remote!=null&&!remote.isBinderAlive())remote=null;}
 void stop(){if(remote!=null)try{call(ShizukuPanService.STOP);}catch(Exception e){fail(e);}}
 String report(){return "Shizuku 服务 · "+(connected()?"已连接 · ":"未连接 · ")+(uid==2000?"无线调试 / shell":uid==0?"Root": "未识别身份")+"\n"+status+(active?"\n接口运行中，是否影响汽水音乐仍需实际试听":"")+(restoring&&!active?"\n请重试停止并恢复；必要时到系统无障碍中调整左右声道平衡":"");}
 void close(){if(closed)return;stop();closed=true;handler.removeCallbacksAndMessages(null);try{if(remote!=null||binding)Shizuku.unbindUserService(args,connection,true);}catch(Exception ignored){}remote=null;}
}
