package cn.xiaohei.sonic.repair;
import android.os.*;import java.lang.reflect.Method;
/** Loaded by Shizuku as shell UID 2000, not as an Android Service. */
public final class ShizukuPanService extends Binder {
 static final String TOKEN="cn.xiaohei.sonic.repair.balance.v1";
 static final int STATUS=1,START=2,STOP=3,HEARTBEAT=4,SESSIONS=5,DESTROY=16777115;
 final BalanceLoop loop;final HandlerThread thread;final Handler worker;IBinder client;boolean dead=false;
 final IBinder.DeathRecipient ownerDied=new IBinder.DeathRecipient(){public void binderDied(){synchronized(ShizukuPanService.this){loop.stop("主程序退出");client=null;}}};
 public ShizukuPanService(){
  loop=new BalanceLoop(new BalanceLoop.Backend(){Method get,set;
   void resolve()throws Exception{if(get==null){Class<?> c=Class.forName("android.media.AudioSystem");get=c.getDeclaredMethod("getMasterBalance");set=c.getDeclaredMethod("setMasterBalance",float.class);}}
   public float read()throws Exception{resolve();return ((Number)get.invoke(null)).floatValue();}
   public int write(float b)throws Exception{resolve();return ((Number)set.invoke(null,b)).intValue();}
  });
  thread=new HandlerThread("sonic-system-balance");thread.start();worker=new Handler(thread.getLooper());worker.post(new Runnable(){public void run(){synchronized(ShizukuPanService.this){if(dead)return;loop.tick(SystemClock.elapsedRealtime());}worker.postDelayed(this,loop.active?25:250);}});
 }
 public synchronized boolean onTransact(int code,Parcel data,Parcel reply,int flags)throws RemoteException{
  if(code==INTERFACE_TRANSACTION){reply.writeString(TOKEN);return true;}
  if(code==DESTROY){loop.stop("关闭服务");dead=true;thread.quitSafely();reply.writeNoException();new Thread(()->{try{Thread.sleep(100);}catch(InterruptedException ignored){}System.exit(0);}).start();return true;}
  if(code<STATUS||code>SESSIONS)return super.onTransact(code,data,reply,flags);
  data.enforceInterface(TOKEN);
  if(code==SESSIONS){int target=data.readInt();try{int[] ids=findSessions(target);reply.writeNoException();reply.writeIntArray(ids);}catch(Exception e){reply.writeException(new IllegalStateException(BalanceLoop.message(e)));}return true;}
  if(code==START){IBinder owner=data.readStrongBinder();int seconds=data.readInt(),depth=data.readInt();if(owner==null)throw new SecurityException("Missing owner token");
   if(client!=owner){if(client!=null)client.unlinkToDeath(ownerDied,0);client=owner;client.linkToDeath(ownerDied,0);}
   loop.start(SystemClock.elapsedRealtime(),seconds,depth);
  }else if(code==STOP)loop.stop("已手动停止");else if(code==HEARTBEAT)loop.beat(SystemClock.elapsedRealtime());
  reply.writeNoException();reply.writeInt(android.os.Process.myUid());reply.writeInt(loop.active?1:0);reply.writeInt(loop.restorePending?1:0);reply.writeFloat(loop.current);reply.writeString(loop.status);return true;
 }
 static int[] findSessions(int uid)throws Exception{
  Class<?> sm=Class.forName("android.os.ServiceManager");IBinder b=(IBinder)sm.getMethod("getService",String.class).invoke(null,"audio");
  Class<?> stub=Class.forName("android.media.IAudioService$Stub");Object audio=stub.getMethod("asInterface",IBinder.class).invoke(null,b);
  java.util.List<?> configs=(java.util.List<?>)Class.forName("android.media.IAudioService").getMethod("getActivePlaybackConfigurations").invoke(audio);
  return PlaybackSessions.matching(configs,uid);
 }

}
