package cn.xiaohei.sonic.repair;
import android.app.*;import android.content.*;import android.os.*;import android.media.*;import android.media.audiofx.*;import android.net.Uri;import java.util.*;
public class SoundService extends Service {
 public static SoundService live;
 final LinkedHashMap<Integer,Rack> racks=new LinkedHashMap<>();
 Settings cfg; ShizukuBridge bridge; volatile CaptureEngine capture; String captureResult="完整音效尚未启动";
 final Handler motionHandler=new Handler(Looper.getMainLooper());
 final Orbit orbit=new Orbit(); long motionTime; float panPosition=0,baseVolume=.65f;
 final Runnable motion=new Runnable(){public void run(){long now=SystemClock.elapsedRealtime();double dt=motionTime==0?0:(now-motionTime)/1000.0;motionTime=now;float[] g=orbit.step(dt,cfg.period,cfg.depth/100.0,cfg.orbit&&cfg.enabled);if(capture==null)panPosition=cfg.shell&&bridge!=null?bridge.position:orbit.position;
  if(player!=null&&prepared)try{player.setVolume(baseVolume*(cfg.shell?1:g[0]),baseVolume*(cfg.shell?1:g[1]));}catch(Exception ignored){}
  for(Rack r:racks.values())r.pan(g[0],g[1]);
  motionHandler.postDelayed(this,(racks.isEmpty()&&player==null)?250:25);
 }};
 Uri lastUri; String lastTitle;
 MediaPlayer player; boolean prepared=false,loading=false,restoreFocus=false; String track="未选择本地音乐",note="等待播放器打开音频会话"; AudioManager am; AudioFocusRequest focus;
 final AudioManager.OnAudioFocusChangeListener focusListener=new AudioManager.OnAudioFocusChangeListener(){public void onAudioFocusChange(int f){if(player==null||!prepared)return;try{if(f==AudioManager.AUDIOFOCUS_LOSS){player.pause();restoreFocus=false;am.abandonAudioFocusRequest(focus);}else if(f==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT){restoreFocus=player.isPlaying();player.pause();}else if(f==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK){baseVolume=.15f;}else if(f==AudioManager.AUDIOFOCUS_GAIN){baseVolume=.65f;if(restoreFocus){player.start();restoreFocus=false;}}}catch(Exception e){note="播放状态已变化";}}};
 final BroadcastReceiver noisy=new BroadcastReceiver(){public void onReceive(Context c,Intent i){pause();}};
 public void onCreate(){super.onCreate();live=this;cfg=new Settings(this);am=(AudioManager)getSystemService(AUDIO_SERVICE);focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).setOnAudioFocusChangeListener(focusListener).build();registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);n.createNotificationChannel(new NotificationChannel("engine","音效引擎",NotificationManager.IMPORTANCE_LOW));startForeground(7,notification(),android.os.Build.VERSION.SDK_INT>=34?android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE:0);bridge=new ShizukuBridge(this);if(cfg.shell)bridge.connect();if(cfg.global)attach(0,"实验性全局输出");motionHandler.post(motion);}
 Notification notification(){PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,SoundService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,"engine").setSmallIcon(cn.xiaohei.sonic.repair.R.drawable.icon).setContentTitle("黑音 · 音效引擎运行中").setContentText("点击调整音效；仅处理已连接的音频会话").setContentIntent(open).addAction(new Notification.Action.Builder(null,"关闭引擎",stop).build()).setOngoing(true).build();}
 public int onStartCommand(Intent i,int f,int id){if(i!=null&&"stop".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}if(i!=null){if("capture".equals(i.getAction())){startCapture(i);return START_NOT_STICKY;}if("shizuku".equals(i.getAction()))bridge.connect();int sid=i.getIntExtra("session",-1);if(sid>0)attach(sid,"播放器指定会话");String uri=i.getStringExtra("uri");if(uri!=null)playUri(Uri.parse(uri),i.getStringExtra("title"));}return START_NOT_STICKY;}
 public IBinder onBind(Intent i){return null;}
 void attach(int id,String label){if(capture!=null)return;if(racks.containsKey(id)){racks.get(id).apply();return;}if(racks.size()>=24){note="会话过多，请关闭引擎后重试";return;}Rack r=new Rack(id,label==null?"外部播放器":label);racks.put(id,r);r.apply();}
 void detach(int id){Rack r=racks.remove(id);if(r!=null)r.release();}
 void reload(){cfg.load();if(capture!=null){capture.sync();if(bridge!=null)bridge.sync();return;}if(cfg.global){if(!racks.containsKey(0))attach(0,"实验性全局输出");}else detach(0);for(Rack r:racks.values())r.apply();if(bridge!=null)bridge.sync();}
 void playUri(Uri uri,String name){if(capture!=null){note="请先停止完整音效，再选择本地音乐";return;}lastUri=uri;lastTitle=name;releasePlayer();track=name==null?"本地音乐":name;try{player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());player.setDataSource(this,uri);baseVolume=.65f;player.setVolume(baseVolume,baseVolume);loading=true;player.setOnPreparedListener(p->{loading=false;prepared=true;attach(p.getAudioSessionId(),"本地播放");reload();if(am.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){p.start();reload();note="本地播放已连接；音量预留了增益余量";}else note="未获得音频焦点，请稍后点播放";});player.setOnCompletionListener(p->{releasePlayer();reload();note="本地播放已结束并释放；已切回外部音效。点播放可重听本地文件。";});player.setOnErrorListener((p,w,e)->{note="无法解码这个文件，请选择 MP3 / FLAC / WAV";releasePlayer();return true;});player.prepareAsync();}catch(Exception e){note="无法打开音乐："+e.getClass().getSimpleName();releasePlayer();}}
 void pause(){if(player!=null&&prepared){try{player.pause();}catch(Exception ignored){}}restoreFocus=false;if(am!=null&&focus!=null)am.abandonAudioFocusRequest(focus);}
 void externalMode(){releasePlayer();reload();note="已结束本地试听并切回外部音效；请在外部 App 重新播放，再查看 8D 引擎状态。";}
 void togglePlay(){if(player==null){if(lastUri!=null)playUri(lastUri,lastTitle);return;}if(!prepared)return;try{if(player.isPlaying())pause();else if(am.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){player.start();restoreFocus=false;}}catch(Exception e){note="播放失败，请重新选择文件";}}
 boolean playing(){try{return player!=null&&prepared&&player.isPlaying();}catch(Exception e){return false;}}
 void releasePlayer(){loading=false;prepared=false;restoreFocus=false;if(player!=null){int sid=player.getAudioSessionId();player.release();player=null;detach(sid);for(Rack r:racks.values())r.setupPan();}if(am!=null&&focus!=null)am.abandonAudioFocusRequest(focus);}
 String report(){if(capture!=null&&capture.probeOnly)return capture.report();if(capture!=null)return capture.report()+"\n\nShizuku 会话发现服务："+(bridge!=null&&bridge.connected()?"已连接":"未连接")+"\n完整音效运行期间暂停旧的系统平衡与会话音效。";StringBuilder b=new StringBuilder();b.append(capture==null?captureResult:capture.report()).append("\n\n");if(bridge!=null)b.append(bridge.report()).append("\n\n");if(cfg.orbit&&cfg.enabled)b.append("8D 左右移动 · ").append(cfg.period).append(" 秒 / 往返 · 深度 ").append(cfg.depth).append("%\n仅控制左右音量，不是头部追踪空间音频。\n\n");if(racks.isEmpty())b.append("尚未连接音频会话\n先打开引擎，再重新播放其他 App 的音乐。\n");for(Rack r:racks.values())b.append(r.label).append(" · #").append(r.id).append("\n").append(r.status()).append("\n");return b.append("\n").append(note).toString();}
 public void onDestroy(){motionHandler.removeCallbacks(motion);if(capture!=null)capture.stop("引擎已关闭");if(bridge!=null)bridge.close();releasePlayer();for(Rack r:racks.values())r.release();racks.clear();try{unregisterReceiver(noisy);}catch(Exception ignored){}live=null;super.onDestroy();}

 void startCapture(Intent intent){
  boolean test=intent.getBooleanExtra("probe",false);
  if(android.os.Build.VERSION.SDK_INT<29){captureResult="完整音效需要 Android 10+";return;}
  if(capture!=null){captureResult="完整音效正在运行或停止中";return;}
  if(!test&&(bridge==null||!bridge.connected())){captureResult="请先授权并连接 Shizuku，再启动完整音效";return;}
  try{
   int target=getPackageManager().getApplicationInfo("com.luna.music",0).uid;
   releasePlayer();for(Rack r:racks.values())r.release();racks.clear();if(test){cfg.shell=false;cfg.global=false;cfg.save();bridge.close();bridge=new ShizukuBridge(this);}else bridge.stop();
   startForeground(7,notification(),(Build.VERSION.SDK_INT>=34?android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE:0)|android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
   android.media.projection.MediaProjectionManager pm=(android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
   Intent grant=intent.getParcelableExtra("projection");
   android.media.projection.MediaProjection projection=pm.getMediaProjection(Activity.RESULT_OK,grant);
   capture=new CaptureEngine(this,projection,target,test);if(!test)bridge.sync();capture.start();
  }catch(Throwable e){captureResult="完整音效启动失败："+BalanceLoop.message(e);startForeground(7,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);}
 }
 void captureEnded(CaptureEngine previous){new Handler(Looper.getMainLooper()).post(()->{if(capture==previous){captureResult=previous.report();capture=null;if(live==this){startForeground(7,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);note=previous.probeOnly?"捕获测试已结束，未压低汽水原声":"完整音效已停止，原声已释放；8D 通道可手动重新连接";}}});}
 void stopCapture(){CaptureEngine c=capture;if(c!=null)c.stop(c.probeOnly?"已手动停止免 Shizuku 捕获测试":"已手动停止完整音效，正在释放原声");}
 final class Rack {
  int id;String label,problem="",panProblem="";Equalizer eq;BassBoost bass;Virtualizer space;DynamicsProcessing panEngine;boolean panTried=false;
  Rack(int s,String l){id=s;label=l;try{eq=new Equalizer(0,id);}catch(Exception e){problem="均衡器不可用（"+e.getClass().getSimpleName()+"）";}try{bass=new BassBoost(0,id);}catch(Exception ignored){}try{space=new Virtualizer(0,id);}catch(Exception ignored){}}
  void check(int result){if(result!=AudioEffect.SUCCESS)throw new IllegalStateException("status "+result);}
  boolean local(){return player!=null&&prepared&&id==player.getAudioSessionId();}
  boolean wantsPan(){
   if(cfg.shell||!cfg.orbit||!cfg.enabled||local())return false;
   // Never pan both a global mix and its individual session at once.
   if(cfg.global)return id==0&&player==null;
   return id>0;
  }
  void setupPan(){
   if(!wantsPan()){if(panEngine!=null){panEngine.release();panEngine=null;}panTried=false;return;}
   if(panEngine!=null||panTried)return;panTried=true;
   if(Build.VERSION.SDK_INT<28){panProblem="外部 8D 需要 Android 9+";return;}
   try{
    DynamicsProcessing.Config c=new DynamicsProcessing.Config.Builder(DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION,2,false,0,false,0,false,0,false).build();
    panEngine=new DynamicsProcessing(0,id,c);
    if(panEngine.getChannelCount()!=2)throw new IllegalStateException("需要双声道输出");
    check(panEngine.setEnabled(true));panProblem="";
   }catch(Exception e){panProblem="8D 引擎不可用："+e.getClass().getSimpleName();if(panEngine!=null){panEngine.release();panEngine=null;}}
  }
  void pan(float l,float r){if(panEngine==null)return;try{if(!panEngine.hasControl()){panProblem="8D 控制权被其他音效占用";return;}panEngine.setInputGainbyChannel(0,Orbit.decibels(l));panEngine.setInputGainbyChannel(1,Orbit.decibels(r));panProblem="";}catch(Exception e){panProblem="8D 参数写入失败："+e.getClass().getSimpleName();try{panEngine.release();}catch(Exception ignored){}panEngine=null;}}
  String panStatus(){if(cfg.shell)return "8D 由 Shizuku 系统平衡通道处理，见上方状态";if(!cfg.orbit||!cfg.enabled)return "8D 左右移动：关闭";if(local())return "8D 左右移动：本地播放已连接";if(cfg.global&&id>0)return "8D 左右移动：由实验性全局引擎尝试处理";if(cfg.global&&player!=null&&id==0)return "8D 全局暂停：避免与本地左右移动叠加";if(!panProblem.isEmpty())return panProblem;return panEngine==null?"8D 左右移动：未连接":"8D 左右移动：引擎已连接，请听感确认";}
  void apply(){setupPan();if(eq!=null)try{short[] range=eq.getBandLevelRange();short count=eq.getNumberOfBands();for(short i=0;i<count;i++){int gain=(int)Math.round(cfg.gain(eq.getCenterFreq(i)/1000.0)*100);eq.setBandLevel(i,(short)Math.max(range[0],Math.min(range[1],gain)));}check(eq.setEnabled(cfg.enabled));problem="";}catch(Exception e){problem="均衡器设置失败："+e.getClass().getSimpleName();}if(bass!=null)try{if(bass.getStrengthSupported())bass.setStrength((short)cfg.bass);check(bass.setEnabled(cfg.enabled&&cfg.bass>0));}catch(Exception ignored){}if(space!=null)try{if(space.getStrengthSupported())space.setStrength((short)cfg.space);check(space.setEnabled(cfg.enabled&&cfg.space>0));}catch(Exception ignored){}}
  String status(){String e=problem;try{if(eq!=null&&e.isEmpty())e=!eq.hasControl()?"均衡器控制权被其他音效占用":(eq.getEnabled()?"均衡器已启用 · "+eq.getNumberOfBands()+" 段":"均衡器已旁路");}catch(Exception x){e="引擎已失效，请重新连接";}String b="不可用",v="不可用";try{if(bass!=null)b=bass.hasControl()?(bass.getEnabled()?"已启用":"关闭"):"被占用";}catch(Exception ignored){}try{if(space!=null)v=space.hasControl()?(space.getEnabled()?"已启用":"关闭"):"被占用";}catch(Exception ignored){}return e+"\n低音 "+b+" · 静态声场 "+v+"\n"+panStatus()+(id==0?"\n全局引擎可创建 ≠ 所有 App 已被处理":"");}
  void release(){if(panEngine!=null)panEngine.release();if(eq!=null)eq.release();if(bass!=null)bass.release();if(space!=null)space.release();}
 }
}
