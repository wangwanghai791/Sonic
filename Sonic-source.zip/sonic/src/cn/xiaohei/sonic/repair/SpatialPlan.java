package cn.xiaohei.sonic.repair;
/** Stable native convolution profiles from the bundled upstream engine. */
final class SpatialPlan {
 static final String[] NAMES={"耳外定位","环绕一","环绕二","真实空间"};
 static int valid(int mode){return Math.max(2,Math.min(5,mode));}
 static boolean active(int preset,boolean enabled){return preset!=0&&enabled;}
 static int crossMode(int preset,boolean enabled,int profile){return active(preset,enabled)?valid(profile):new FxPlan(preset).crossMode;}
 static boolean crossEnabled(int preset,boolean enabled){return active(preset,enabled)||new FxPlan(preset).cross;}
}
