package cn.xiaohei.sonic.repair;
/** Linear dry/wet crossfade shared by both independent effects. */
final class StageMix {
 static void apply(float[] dry,float[] wet,float[] out,int n,float from,float to){
  int pairs=n/2;
  for(int frame=0;frame<pairs;frame++){
   float mix=Math.max(0,Math.min(1,from+(to-from)*(frame+1f)/pairs));
   for(int ch=0;ch<2;ch++){int i=frame*2+ch;float value=dry[i]+(wet[i]-dry[i])*mix;if(!Float.isFinite(value))throw new IllegalStateException("独立音效输出异常");out[i]=value;}
  }
 }
}
