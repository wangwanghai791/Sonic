package cn.xiaohei.sonic.repair;
import java.util.Locale;
/** Original, conservative tonal controls; not an implementation of HiBy MSEB. */
final class TonePlan {
 static final int[] HZ={60,120,230,500,1000,2500,4000,6500,9000,14000};
 static int clamp(int x,int low,int high){return Math.max(low,Math.min(high,x));}
 static String curve(int mode,String base,int warmth,int voice,int soft){
  if(mode==0)return "";
  warmth=clamp(warmth,-50,50);voice=clamp(voice,-50,50);soft=clamp(soft,0,100);
  if(warmth==0&&voice==0&&soft==0&&mode<10)return base;
  double w=warmth/50.0,v=voice/50.0,s=soft/100.0;
  if(mode==11){w+=.55;s+=.15;}if(mode==12)v+=.65;if(mode==13)s+=.7;
  double[] ws={1.5,2,1.6,.8,0,-.4,-.8,-1.2,-1.5,-2};
  double[] vs={-.5,-.7,-1,-.3,1.2,2,1.2,-.4,-.4,-.4};
  double[] ss={0,0,0,0,0,0,-.5,-3,-2,-.5};
  StringBuilder b=new StringBuilder();
  for(int i=0;i<HZ.length;i++){double gain=interpolate(base,HZ[i])+w*ws[i]+v*vs[i]+s*ss[i];gain=Math.max(-8,Math.min(5,gain));if(i>0)b.append(';');b.append(HZ[i]).append(' ').append(String.format(Locale.ROOT,"%.3f",gain));}return b.toString();
 }
 static double interpolate(String base,int hz){if(base.isEmpty())return 0;double priorHz=0,priorGain=0;for(String item:base.split(";")){String[] p=item.trim().split("\\s+");double f=Double.parseDouble(p[0]),g=Double.parseDouble(p[1]);if(hz<=f){if(priorHz==0)return g;double t=Math.log(hz/priorHz)/Math.log(f/priorHz);return priorGain+(g-priorGain)*t;}priorHz=f;priorGain=g;}return priorGain;}
}
