package me.timschneeberger.rootlessjamesdsp.interop;
/** JNI declarations compatible with upstream RootlessJamesDSP 1.6.14, GPL-3.0. */
public final class JamesDspWrapper {
 static{System.loadLibrary("jamesdsp-wrapper");}
 public native int getBenchmarkSize();public native void loadBenchmark(double[] c0,double[] c1);
 public native long alloc(Object callbacks);public native void free(long h);
 public native void setSamplingRate(long h,float rate,boolean force);
 public native void processFloat(long h,float[] input,float[] output,int offset,int count);
 public native boolean setLimiter(long h,float threshold,float release);
 public native boolean setPostGain(long h,float gain);
 public native boolean setReverb(long h,boolean on,int preset);
 public native boolean setBassBoost(long h,boolean on,float gain);
 public native boolean setCrossfeed(long h,boolean on,int mode,int fcut,int feed);
 public native boolean setStereoEnhancement(long h,boolean on,float level);
 public native boolean setVacuumTube(long h,boolean on,float level);
 public native boolean setGraphicEq(long h,boolean on,String curve);
 public static final class Callbacks {
  public void onLiveprogOutput(String s){}public void onLiveprogExec(String s){}
  public void onLiveprogResult(int c,String id,String error){}public void onVdcParseError(){}
 }
}
