package cn.xiaohei.sonic.repair;
public final class BalanceLoopTest {
 static class Fake implements BalanceLoop.Backend {float value=.2f;boolean deny;int writes;public float read(){return value;}public int write(float b){writes++;if(deny)return -1;value=b;return 0;}}
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  Fake nativeAudio=new Fake();BalanceLoop pan=new BalanceLoop(nativeAudio);
  pan.start(0,8,100);check(pan.active,"Must start after successful interface probe");float min=1,max=-1;
  for(long t=25;t<=16000;t+=25){if(t%1000==0)pan.beat(t);pan.tick(t);min=Math.min(min,nativeAudio.value);max=Math.max(max,nativeAudio.value);check(Math.abs(nativeAudio.value)<=1,"Global balance out of range");}
  check(min<-.98&&max>.98,"Both directions must be reached");
  pan.start(16000,3,45);check(pan.original==.2f,"Changing speed/depth must preserve original balance");
  pan.stop("test");check(!pan.active&&!pan.restorePending&&nativeAudio.value==.2f,"Normal stop must restore pre-existing balance");
  pan.start(17000,8,100);pan.tick(17200);pan.tick(22001);check(!pan.active&&nativeAudio.value==.2f,"Watchdog must restore balance after heartbeat expires");
  nativeAudio.deny=true;pan.start(23000,8,100);check(!pan.active&&pan.status.contains("-1"),"Permission denial must not appear as a working engine");
  nativeAudio.deny=false;pan.start(24000,8,100);nativeAudio.deny=true;pan.tick(24100);check(!pan.active&&pan.restorePending,"Failure while restoring must remain visible and retryable");
  nativeAudio.deny=false;pan.stop("retry");check(!pan.restorePending&&nativeAudio.value==.2f,"Restoration retry must recover original balance");
  pan.start(25000,8,0);for(int i=0;i<100;i++){pan.beat(25000+i*25);pan.tick(25000+i*25);}check(Math.abs(nativeAudio.value)<.001,"Depth zero must center balance while active");pan.stop("done");
  System.out.println("PASS: global range, both ears, live parameters, original balance restoration, heartbeat timeout, permission denial, failure visibility and restoration retry");
 }
}
