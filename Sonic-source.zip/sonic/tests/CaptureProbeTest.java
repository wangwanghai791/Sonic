package cn.xiaohei.sonic.repair;
public final class CaptureProbeTest {
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
 public static void main(String[] args){CaptureProbe probe=new CaptureProbe();
  check(!probe.previewing(0),"Playback must be silent by default");
  probe.record(new float[1024],1024);check(!probe.signalSeen&&probe.capturedFrames==512,"Zero frames must not count as audio signal");
  probe.requestPreview(1000);check(!probe.previewing(1001),"No signal must not enable playback");
  probe.record(new float[]{.1f,-.2f,0,.05f},4);check(probe.signalSeen&&probe.peak==.2f,"Capture meter must report observed signal");
  check(probe.previewing(1001)&&probe.previewing(5999),"Explicit preview must play inside its window");check(!probe.previewing(6000),"Preview must expire at five seconds");
  probe.record(new float[4],4);check(probe.signalSeen&&probe.peak==0,"Keep historical signal evidence while current input is silent");
  check(!probe.previewing(7000),"Later input must not restart expired preview");probe.requestPreview(8000);check(probe.previewing(8001),"Explicit re-request must open a new preview");probe.stopPreview();check(!probe.previewing(8002),"Stopping preview must immediately disable output");
  boolean rejected=false;try{probe.record(new float[]{Float.NaN,0},2);}catch(IllegalStateException expected){rejected=true;}check(rejected,"Invalid capture samples must not reach output");
  System.out.println("PASS: silent default, real signal detection, accurate peak, captured-frame counting, explicit preview, five-second expiration, no auto-resume, stop and invalid-sample rejection");
 }
}
