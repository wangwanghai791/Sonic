package cn.xiaohei.sonic.repair;
public final class NativeHandleTest {
 static void check(boolean value,String text){if(!value)throw new AssertionError(text);}
 public static void main(String[] args){
  long tagged=-5476376660715781248L;
  check(NativeHandle.allocated(tagged),"User's real tagged pointer was rejected");
  check(NativeHandle.require(tagged)==tagged,"Pointer bits were changed");
  check(NativeHandle.allocated(0x0000007654321000L),"Untagged pointer was rejected");
  check(NativeHandle.allocated(Long.MIN_VALUE),"Signed high bit must not determine allocation status");
  for(long error:new long[]{0,1,2}){check(!NativeHandle.allocated(error),"Allocation sentinel was accepted");boolean threw=false;try{NativeHandle.require(error);}catch(IllegalStateException expected){threw=true;}check(threw,"Allocation error must remain visible");}
  System.out.println("PASS: real device tagged handle, unchanged pointer bits, positive handles, signed high bit, and all upstream allocation error sentinels");
 }
}
