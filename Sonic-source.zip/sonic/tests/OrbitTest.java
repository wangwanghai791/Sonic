package cn.xiaohei.sonic.repair;
/** JVM behavioral checks for the actual runtime panner. Run with assertions enabled. */
public final class OrbitTest {
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 public static void main(String[] args){
  Orbit p=new Orbit();double sumL=0,sumR=0;float maxL=0,maxR=0,previousL=1,previousR=1;
  for(int i=0;i<1920;i++){
   float[] g=p.step(.025,8,1,true);
   check(Float.isFinite(g[0])&&Float.isFinite(g[1])&&g[0]>=0&&g[1]>=0&&g[0]<=1&&g[1]<=1,"Channel gain exceeded safe bounds");
   check(Math.abs(g[0]-previousL)<.05&&Math.abs(g[1]-previousR)<.05,"Audible gain discontinuity during orbit");
   if(i>320){sumL+=g[0]*g[0];sumR+=g[1]*g[1];}
   maxL=Math.max(maxL,g[0]-g[1]);maxR=Math.max(maxR,g[1]-g[0]);previousL=g[0];previousR=g[1];
  }
  check(maxL>.98&&maxR>.98,"Both ears must receive alternating dominance");
  check(Math.abs(sumL-sumR)/Math.max(sumL,sumR)<.01,"Orbit must not favor one ear over full cycles");
  float[] g=null;for(int i=0;i<100;i++)g=p.step(.025,8,1,false);
  check(Math.abs(g[0]-1)<.0001&&Math.abs(g[1]-1)<.0001,"Bypass failed to restore both channels");
  for(int i=0;i<100;i++)g=p.step(.025,8,0,true);
  check(Math.abs(g[0]-g[1])<.0001,"Zero depth must leave centered audio");
  Orbit fast=new Orbit();fast.step(.5,2,1,true);check(fast.position>.99,"2-second period did not reach right ear at quarter-cycle");
  fast.step(1,2,1,true);check(fast.position<-.99,"2-second period did not reach left ear at three-quarter-cycle");
  check(Orbit.decibels(0)==-60&&Orbit.decibels(1)==0,"External engine dB mapping invalid");
  System.out.println("PASS: alternating ears, full-cycle balance, bounded gains, continuous motion, bypass, depth, speed, and external dB mapping");
 }
}
