package cn.xiaohei.sonic.repair;
import java.util.*;
public final class PlaybackSessionsTest {
 public static final class Config {
  final int uid,session;final boolean active;
  Config(int u,int s,boolean a){uid=u;session=s;active=a;}
  public int getClientUid(){return uid;}
  public boolean isActive(){return active;}
  public int getSessionId(){return session;}
  // Deliberately no getAudioSessionId: matches the platform API.
 }
 public static final class Unsupported {
  public int getClientUid(){return 42;}
  public boolean isActive(){return true;}
 }
 public static void main(String[] args)throws Exception {
  List<Config> input=Arrays.asList(new Config(42,123,true),new Config(42,123,true),new Config(42,456,true),new Config(43,789,true),new Config(42,99,false),new Config(-1,0,true),new Config(42,0,true));
  if(!Arrays.equals(PlaybackSessions.matching(input,42),new int[]{123,456}))throw new AssertionError("Target UID, active status, deduplication and nonzero IDs");
  if(PlaybackSessions.matching(Collections.emptyList(),42).length!=0)throw new AssertionError("Empty list");
  boolean reported=false;try{PlaybackSessions.matching(Arrays.asList(new Unsupported()),42);}catch(NoSuchMethodException expected){reported=true;}
  if(!reported)throw new AssertionError("Do not hide unsupported platform methods");
  System.out.println("PASS: platform getSessionId method; target UID only; active, nonzero, deduplicated sessions; unsupported methods remain visible");
 }
}
