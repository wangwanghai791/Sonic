package cn.xiaohei.sonic.repair;
public final class SpatialPlanTest {
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[] args){
  for(int preset=0;preset<FxPlan.NAMES.length;preset++){
   FxPlan old=new FxPlan(preset);
   check(SpatialPlan.crossMode(preset,false,5)==old.crossMode,"Disabled spatial preserves old crossfeed profile");
   check(SpatialPlan.crossEnabled(preset,false)==old.cross,"Disabled spatial preserves old effects");
   for(int profile=2;profile<=5;profile++){
    check(SpatialPlan.crossEnabled(preset,true)==(preset!=0),"Original bypass remains unprocessed");
    if(preset!=0)check(SpatialPlan.crossMode(preset,true,profile)==profile,"Explicit spatial profile reaches native engine");
   }
  }
  check(SpatialPlan.valid(-100)==2&&SpatialPlan.valid(999)==5,"Stored profile is bounded");
  System.out.println("PASS: all 14 presets preserve prior behavior with spatial disabled; 4 profiles compose with effects; original bypass and profile bounds");
 }
}
