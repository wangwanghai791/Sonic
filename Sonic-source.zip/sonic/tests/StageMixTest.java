package cn.xiaohei.sonic.repair;
public final class StageMixTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  float[] dry={.2f,-.2f,.4f,-.4f},wet={.6f,-.6f,.8f,-.8f},out=new float[4];
  StageMix.apply(dry,wet,out,4,0,0);check(out[0]==dry[0]&&out[3]==dry[3]);
  StageMix.apply(dry,wet,out,4,1,1);check(Math.abs(out[0]-wet[0])<1e-6&&Math.abs(out[3]-wet[3])<1e-6);
  StageMix.apply(dry,wet,out,4,0,1);check(Math.abs(out[0]-.4f)<1e-6&&Math.abs(out[1]+.4f)<1e-6&&Math.abs(out[2]-.8f)<1e-6);
  StageMix.apply(dry,wet,out,4,0,0);StageMix.apply(out,wet,out,4,1,1);check(Math.abs(out[2]-.8f)<1e-6);
  boolean rejected=false;try{StageMix.apply(dry,new float[]{Float.NaN,0,0,0},out,4,1,1);}catch(IllegalStateException e){rejected=true;}check(rejected);
  System.out.println("PASS: independent zero/full wet endpoints, stereo-linked smooth transition, in-place chain composition and invalid PCM rejection");
 }
}
