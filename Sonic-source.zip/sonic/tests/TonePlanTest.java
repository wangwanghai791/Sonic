package cn.xiaohei.sonic.repair;
import java.io.*;
public final class TonePlanTest {
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[] args)throws Exception {
  check(TonePlan.curve(0,"60 5",50,50,100).isEmpty(),"Bypass ignores all tonal adjustments");
  String old=new FxPlan(4).eq;check(TonePlan.curve(4,old,0,0,0).equals(old),"Neutral controls preserve existing preset");
  String warm=TonePlan.curve(10,"",50,0,0),soft=TonePlan.curve(10,"",0,0,100),voice=TonePlan.curve(10,"",0,50,0);
  check(TonePlan.interpolate(warm,120)>TonePlan.interpolate(warm,9000),"Warmth tilts low and high frequencies");
  check(TonePlan.interpolate(soft,6500)<-2&&TonePlan.interpolate(soft,1000)==0,"Softness targets high frequencies");
  check(TonePlan.interpolate(voice,2500)>TonePlan.interpolate(voice,230),"Vocal control targets presence band");
  check(TonePlan.curve(10,"",999,-999,999).equals(TonePlan.curve(10,"",50,-50,100)),"Inputs are clamped");
  PrintWriter out=new PrintWriter(args[0],"UTF-8");int count=0;
  for(int mode=0;mode<FxPlan.NAMES.length;mode++)for(int w:new int[]{-50,0,50})for(int v:new int[]{-50,0,50})for(int s:new int[]{0,100}){
   String eq=TonePlan.curve(mode,new FxPlan(mode).eq,w,v,s);
   if(!eq.isEmpty()){for(String item:eq.split(";")){double gain=Double.parseDouble(item.trim().split("\\s+")[1]);check(Double.isFinite(gain)&&gain>=-8&&gain<=5,"Gain within supported bound");}out.println(eq);count++;}
  }out.close();System.out.println("PASS: bypass, neutral compatibility, perceptual directions, clamping; "+count+" native test curves exported");
 }
}
