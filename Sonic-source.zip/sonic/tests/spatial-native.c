#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "jdsp_header.h"
int main(){
 double c0[10]={.000025,.00005,.0001,.0002,.0005,.001,.0021,.0057,.0126,.0293},c1[10]={.000003125,.00000625,.0000125,.000025,.00005,.0001,.0002,.0004,.0009,.0019};
 JamesDSPGlobalMemoryAllocation();JamesDSP_Load_benchmark(c0,c1);double energies[4]={0};
 for(int mode=2;mode<=5;mode++){
  JamesDSPLib *d=calloc(1,sizeof(*d));JamesDSPInit(d,512,48000);JLimiterSetCoefficients(d,-1,60);JamesDSPSetPostGain(d,-2);
  CrossfeedChangeMode(d,mode);CrossfeedEnable(d,1);float input[1024],output[1024];double left=0,right=0;int seen=0;
  for(int block=0;block<220;block++){
   for(int i=0;i<1024;i++)input[i]=0;if(block==0)input[0]=.3f;
   d->processFloatMultiplexd(d,input,output,512);
   for(int i=0;i<512;i++){float l=output[2*i],r=output[2*i+1];if(!isfinite(l)||!isfinite(r)||fabsf(l)>1||fabsf(r)>1)return 2;left+=l*l;right+=r*r;if(l!=0||r!=0)seen++;}
  }
  printf("profile %d: left-only impulse -> L energy %.9f, R energy %.9f; %d nonzero frames\n",mode,left,right,seen);
  if(left<1e-9||right<1e-9||seen<8)return 3;energies[mode-2]=left+right;
  /* Exercise repeated on/off and profile changes using the same instance. */
  for(int p=5;p>=2;p--){CrossfeedDisable(d);CrossfeedChangeMode(d,p);CrossfeedEnable(d,1);}
  /* Test the combined chain exposed by the new UI (hall plus spatial). */
  Reverb_SetParam(d,5);ReverbEnable(d);StereoEnhancementSetParam(d,.4);StereoEnhancementEnable(d);
  for(int block=0;block<60;block++){for(int i=0;i<512;i++){int n=block*512+i;input[2*i]=.08*sin(n*6.283185307*440/48000);input[2*i+1]=.07*sin(n*6.283185307*650/48000);}d->processFloatMultiplexd(d,input,output,512);for(int i=0;i<1024;i++)if(!isfinite(output[i])||fabsf(output[i])>1)return 4;}
  JamesDSPFree(d);free(d);
 }
 int distinct=0;for(int i=1;i<4;i++)if(fabs(energies[i]-energies[i-1])>1e-8)distinct++;JamesDSPGlobalMemoryDeallocation();if(distinct<3)return 5;
 puts("PASS: four distinct convolution profiles produce cross-ear impulse responses; finite bounded PCM, switching and hall/spatial composition");return 0;
}
