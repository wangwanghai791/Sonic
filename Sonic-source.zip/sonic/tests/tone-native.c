#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "jdsp_header.h"
int main(int argc,char **argv){
 FILE *f=argc==2?fopen(argv[1],"r"):NULL;if(!f)return 1;
 JamesDSPLib *d=calloc(1,sizeof(*d));JamesDSPGlobalMemoryAllocation();JamesDSPInit(d,512,48000);
 double c0[10]={.000025,.00005,.0001,.0002,.0005,.001,.0021,.0057,.0126,.0293},c1[10]={.000003125,.00000625,.0000125,.000025,.00005,.0001,.0002,.0004,.0009,.0019};JamesDSP_Load_benchmark(c0,c1);
 JLimiterSetCoefficients(d,-1,60);JamesDSPSetPostGain(d,-2);float input[1024],output[1024];char eq[2048];int count=0;
 while(fgets(eq,sizeof(eq),f)){eq[strcspn(eq,"\n")]=0;ArbitraryResponseEqualizerStringParser(d,eq);ArbitraryResponseEqualizerEnable(d,1);double energy=0;
  for(int block=0;block<12;block++){for(int i=0;i<512;i++){int n=512*block+i;input[2*i]=.08*sin(n*6.283185307*120/48000)+.06*sin(n*6.283185307*2500/48000)+.04*sin(n*6.283185307*6500/48000);input[2*i+1]=input[2*i]*.8;}d->processFloatMultiplexd(d,input,output,512);for(int i=0;i<1024;i++){if(!isfinite(output[i])||fabsf(output[i])>1)return 2;energy+=output[i]*output[i];}}
  if(energy<.001)return 3;count++;
 }
 fclose(f);JamesDSPFree(d);free(d);JamesDSPGlobalMemoryDeallocation();printf("PASS: %d tonal curves processed by actual JamesDSP with nonzero, finite, bounded stereo PCM\n",count);return count>200?0:4;
}
